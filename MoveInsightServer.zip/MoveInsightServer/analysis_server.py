from fastapi import FastAPI, HTTPException, Request, File, UploadFile, Form
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Dict, List, Any, Optional
import numpy as np
import logging
import time
import traceback
import cv2
import mediapipe as mp
import tempfile
import os

# Import functions from swing_diagnose.py
from swing_diagnose import evaluate_swing_rules, align_keypoints_with_interpolation

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("analysis_server")

# --- FastAPI App Setup ---
app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"],
)

@app.middleware("http")
async def log_requests(request: Request, call_next):
    start_time = time.time()
    client_host = request.client.host if request.client else "unknown"
    logger.info(f"Request started: {request.method} {request.url.path} - Client: {client_host}")
    try:
        response = await call_next(request)
        process_time = time.time() - start_time
        logger.info(f"Request completed: {request.method} {request.url.path} - {response.status_code} in {process_time:.2f}s")
        return response
    except Exception as e:
        logger.error(f"Request failed: {request.method} {request.url.path} - Error: {str(e)} - Traceback: {traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=f"Internal Server Error: {str(e)}")

# --- MediaPipe Pose Estimation Setup ---
mp_pose = mp.solutions.pose
JOINT_MAP = {
    0: 'Nose', 11: 'LeftShoulder', 12: 'RightShoulder', 13: 'LeftElbow', 14: 'RightElbow',
    15: 'LeftWrist', 16: 'RightWrist', 23: 'LeftHip', 24: 'RightHip', 25: 'LeftKnee',
    26: 'RightKnee', 27: 'LeftAnkle', 28: 'RightAnkle', 29: 'LeftHeel', 30: 'RightHeel',
    31: 'LeftFootIndex', 32: 'RightFootIndex'
}
JOINT_NAME_REMAPPING = { 'LeftFootIndex': 'LeftToe', 'RightFootIndex': 'RightToe' }

# --- Pydantic Models ---
class JointDataItem(BaseModel):
    x: float
    y: float
    confidence: Optional[float] = None

class FrameDataItem(BaseModel):
    joints: Dict[str, JointDataItem]

class VideoAnalysisResponseModel(BaseModel):
    total_frames: int
    joint_data_per_frame: List[FrameDataItem]
    swing_analysis: Optional[Dict[str, bool]] = None

# For Technique Comparison Endpoint
class TechniqueComparisonRequestDataModel(BaseModel):
    user_video_frames: List[FrameDataItem]
    model_video_frames: List[FrameDataItem]
    dominant_side: str

class ComparisonResultModel(BaseModel):
    user_score: float
    reference_score: float
    similarity: Dict[str, bool]
    user_details: Dict[str, bool]
    reference_details: Dict[str, bool]

# --- Helper Functions ---
def transform_pydantic_to_numpy(joint_data_per_frame_pydantic: List[FrameDataItem]) -> Dict[str, List]:
    """
    Transform pydantic models to format needed for align_keypoints_with_interpolation
    """
    joint_data = {}
    
    if not joint_data_per_frame_pydantic:
        return joint_data
    
    # Get all unique joint names
    all_joint_names = set()
    for frame_data in joint_data_per_frame_pydantic:
        all_joint_names.update(frame_data.joints.keys())
    
    # Initialize lists for each joint
    for joint_name in all_joint_names:
        joint_data[joint_name] = []
    
    # Fill in data frame by frame
    for frame_data in joint_data_per_frame_pydantic:
        for joint_name in all_joint_names:
            if joint_name in frame_data.joints:
                joint_info = frame_data.joints[joint_name]
                joint_data[joint_name].append([joint_info.x, joint_info.y])
    
    return joint_data

def transform_numpy_to_pydantic(keypoints: Dict[str, np.ndarray], frame_count: int) -> List[FrameDataItem]:
    """
    Transform numpy arrays back to pydantic models for response
    """
    result = []
    
    for frame_idx in range(frame_count):
        frame_joints = {}
        for joint_name, points_array in keypoints.items():
            if frame_idx < len(points_array):
                point = points_array[frame_idx]
                frame_joints[joint_name] = JointDataItem(
                    x=float(point[0]), 
                    y=float(point[1]),
                    confidence=0.9  # Default confidence if not available
                )
        
        result.append(FrameDataItem(joints=frame_joints))
    
    return result

# --- API Endpoints ---
@app.post("/analyze/video_upload/", response_model=VideoAnalysisResponseModel)
async def analyze_video_upload(
    file: UploadFile = File(...),
    dominant_side: str = Form("Right")
):
    logger.info(f"Received video upload: {file.filename}, dominant side: {dominant_side}")
    temp_video_path = ""
    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix=".mp4") as tmp:
            tmp.write(await file.read())
            temp_video_path = tmp.name
        logger.info(f"Video saved temporarily to: {temp_video_path}")

        # Dictionary to store joint data (key: joint name, value: list of [x,y] coordinates)
        joint_data = {}
        frame_count = 0

        with mp_pose.Pose(static_image_mode=False, model_complexity=1, min_detection_confidence=0.5, min_tracking_confidence=0.5) as pose_estimator:
            cap = cv2.VideoCapture(temp_video_path)
            if not cap.isOpened():
                raise HTTPException(status_code=400, detail="Could not open video file.")

            # Initialize joint data dictionary
            for idx, joint_name in JOINT_MAP.items():
                # Apply remapping if needed
                mapped_name = JOINT_NAME_REMAPPING.get(joint_name, joint_name)
                joint_data[mapped_name] = []

            while cap.isOpened():
                success, frame = cap.read()
                if not success: break
                frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                results = pose_estimator.process(frame_rgb)
                
                if results.pose_landmarks:
                    for idx, lm in enumerate(results.pose_landmarks.landmark):
                        if idx in JOINT_MAP:
                            original_joint_name = JOINT_MAP[idx]
                            joint_name_for_client = JOINT_NAME_REMAPPING.get(original_joint_name, original_joint_name)
                            joint_data[joint_name_for_client].append([lm.x, lm.y])
                
                frame_count += 1
            
            cap.release()
        
        logger.info(f"Processed {frame_count} frames from video.")

        if frame_count == 0:
            logger.warning("No frames detected in the video.")
            return VideoAnalysisResponseModel(total_frames=0, joint_data_per_frame=[], swing_analysis=None)

        # Use align_keypoints_with_interpolation from swing_diagnose.py
        keypoints = align_keypoints_with_interpolation(joint_data, frame_count)
        
        # Convert keypoints to pydantic models for response
        joint_data_per_frame_pydantic = transform_numpy_to_pydantic(keypoints, frame_count)
        
        # Use evaluate_swing_rules from swing_diagnose.py
        swing_analysis_results = None
        required_keys = [
            'RightShoulder', 'LeftShoulder', 'RightElbow', 'LeftElbow', 'RightWrist',
            'RightHip', 'LeftHip', 'RightHeel', 'RightToe', 'LeftHeel', 'LeftToe'
        ]
        
        if all(k in keypoints for k in required_keys):
            try:
                swing_analysis_results = evaluate_swing_rules(keypoints, dominant_side=dominant_side)
                logger.info(f"Swing analysis for dominant side {dominant_side}: {swing_analysis_results}")
            except Exception as e:
                logger.error(f"Error in evaluate_swing_rules: {str(e)}")
                swing_analysis_results = {
                    'shoulder_abduction': False, 'elbow_flexion': False, 'elbow_lower': False,
                    'foot_direction_aligned': False, 'proximal_to_distal_sequence': False,
                    'hip_forward_shift': False, 'trunk_rotation_completed': False
                }
        else:
            logger.warning("Missing required key points for swing evaluation")
            swing_analysis_results = {
                'shoulder_abduction': False, 'elbow_flexion': False, 'elbow_lower': False,
                'foot_direction_aligned': False, 'proximal_to_distal_sequence': False,
                'hip_forward_shift': False, 'trunk_rotation_completed': False
            }

        logger.info(f"Returning {len(joint_data_per_frame_pydantic)} frames of aligned joint data and swing analysis.")
        return VideoAnalysisResponseModel(
            total_frames=frame_count,
            joint_data_per_frame=joint_data_per_frame_pydantic,
            swing_analysis=swing_analysis_results
        )
    finally:
        if temp_video_path and os.path.exists(temp_video_path):
            os.unlink(temp_video_path)
            logger.info(f"Temporary video file {temp_video_path} deleted.")

@app.post("/analyze/technique_comparison/", response_model=ComparisonResultModel)
async def analyze_technique_comparison(data: TechniqueComparisonRequestDataModel):
    logger.info(f"Received technique comparison request for dominant side: {data.dominant_side}")

    # Transform pydantic models to format needed for processing
    user_joint_data = transform_pydantic_to_numpy(data.user_video_frames)
    model_joint_data = transform_pydantic_to_numpy(data.model_video_frames)
    
    user_frame_count = len(data.user_video_frames)
    model_frame_count = len(data.model_video_frames)
    
    logger.info(f"Processing {user_frame_count} user video frames and {model_frame_count} model video frames for comparison.")
    
    # Use align_keypoints_with_interpolation to process the data
    user_keypoints = align_keypoints_with_interpolation(user_joint_data, user_frame_count)
    model_keypoints = align_keypoints_with_interpolation(model_joint_data, model_frame_count)
    
    # Use evaluate_swing_rules to analyze both videos
    user_swing_details = evaluate_swing_rules(user_keypoints, data.dominant_side)
    model_swing_details = evaluate_swing_rules(model_keypoints, data.dominant_side)
    
    # Calculate scores and similarity
    num_criteria = len(user_swing_details)
    
    user_correct_criteria = sum(1 for v in user_swing_details.values() if v)
    user_score = (user_correct_criteria / num_criteria) * 100.0 if num_criteria > 0 else 0.0

    model_correct_criteria = sum(1 for v in model_swing_details.values() if v)
    reference_score = (model_correct_criteria / num_criteria) * 100.0 if num_criteria > 0 else 0.0

    similarity = {}
    for rule_name in user_swing_details.keys():
        similarity[rule_name] = (user_swing_details.get(rule_name, False) == model_swing_details.get(rule_name, False))
    
    logger.info(f"Comparison complete: User Score {user_score}, Reference Score {reference_score}")

    return ComparisonResultModel(
        user_score=user_score,
        reference_score=reference_score,
        similarity=similarity,
        user_details=user_swing_details,
        reference_details=model_swing_details
    )

@app.get("/")
async def root():
    return {"status": "MoveInsight Analysis Server is running", "version": "1.2.0 - Using swing_diagnose.py"}

if __name__ == "__main__":
    import uvicorn
    logger.info("Starting MoveInsight Analysis Server...")
    uvicorn.run(app, host="0.0.0.0", port=8000, log_level="info")